
.. _constrain.ConstraintsExclusion:

.. |Constraint| replace:: ConstraintsExclusion

Constraints exclusion
---------------------

.. autoclass:: pyasn1.type.constraint.ConstraintsExclusion(constraint)
   :members:
